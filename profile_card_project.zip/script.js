const followBtn = document.querySelector('.btn-primary');

followBtn.addEventListener('click', () => {
  if (followBtn.textContent === 'Подписаться') {
    followBtn.textContent = 'Вы подписаны';
    followBtn.style.background = '#22c55e';
  } else {
    followBtn.textContent = 'Подписаться';
    followBtn.style.background = '#667eea';
  }
});
