num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
s = (num1 * num2) / 2
print(s)