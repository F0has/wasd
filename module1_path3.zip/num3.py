metres = int(input("Enter a metre: "))
sm = metres * 100
dm = metres * 10
mm = metres * 1000
miles = metres * 1609,34
print (metres, sm, dm, mm, miles)
