num1 = input("Enter a number: ")
num2 = num1[::-1]
print(num2)