import sqlite3
import os
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'cloud-observer-secret-key'

# Путь к файлу базы данных
DB_PATH = os.path.join(os.path.dirname(__file__), 'database.db')

# Допустимые типы облаков
CLOUD_TYPES = {
    'undulatus':   'Волнистые (Undulatus)',
    'mammatus':    'Вымеобразные (Mammatus)',
    'lenticularis':'Линзовидные (Lenticularis)',
    'asperitas':   'Шероховатые (Asperitas)',
    'arcus':       'Дуговые (Arcus)',
    'other':       'Другое (Other)',
}


def get_db():
    """Открывает соединение с базой данных."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # позволяет обращаться к полям по имени
    return conn


def init_db():
    """Создаёт таблицу, если она ещё не существует."""
    conn = get_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS observations (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            location    TEXT NOT NULL,
            cloud_type  TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            description TEXT,
            observer    TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()


@app.route('/')
def index():
    """Главная страница: список всех наблюдений с возможностью фильтрации."""
    cloud_type_filter = request.args.get('type', '')  # читаем ?type=... из URL

    conn = get_db()
    if cloud_type_filter and cloud_type_filter in CLOUD_TYPES:
        # Фильтруем по выбранному типу
        rows = conn.execute(
            'SELECT * FROM observations WHERE cloud_type = ? ORDER BY observed_at DESC',
            (cloud_type_filter,)
        ).fetchall()
    else:
        # Показываем все наблюдения
        rows = conn.execute(
            'SELECT * FROM observations ORDER BY observed_at DESC'
        ).fetchall()
    conn.close()

    return render_template(
        'index.html',
        observations=rows,
        cloud_types=CLOUD_TYPES,
        active_filter=cloud_type_filter
    )


@app.route('/add', methods=['GET', 'POST'])
def add():
    """Страница добавления нового наблюдения."""
    if request.method == 'POST':
        # Читаем данные из формы
        location   = request.form.get('location', '').strip()
        cloud_type = request.form.get('cloud_type', '').strip()
        observed_at = request.form.get('observed_at', '').strip()
        description = request.form.get('description', '').strip()
        observer   = request.form.get('observer', '').strip()

        # Серверная валидация
        errors = []
        if not location:
            errors.append('Укажите место наблюдения.')
        if cloud_type not in CLOUD_TYPES:
            errors.append('Выберите корректный тип облака.')
        if not observed_at:
            errors.append('Укажите дату и время наблюдения.')
        if not observer:
            errors.append('Укажите имя наблюдателя.')

        if errors:
            for e in errors:
                flash(e, 'error')
            # Возвращаем форму с теми же данными, чтобы не терять введённое
            return render_template(
                'add.html',
                cloud_types=CLOUD_TYPES,
                form_data=request.form
            )

        # Сохраняем в базу данных
        conn = get_db()
        conn.execute(
            '''INSERT INTO observations (location, cloud_type, observed_at, description, observer)
               VALUES (?, ?, ?, ?, ?)''',
            (location, cloud_type, observed_at, description, observer)
        )
        conn.commit()
        conn.close()

        flash('Наблюдение успешно добавлено!', 'success')
        return redirect(url_for('index'))

    # GET — просто показываем пустую форму
    return render_template('add.html', cloud_types=CLOUD_TYPES, form_data={})


if __name__ == '__main__':
    init_db()          # создаём таблицу при первом запуске
    app.run(debug=True)
